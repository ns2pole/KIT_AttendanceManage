-- data.sql
INSERT INTO tasks (name, deadlinedate, planminute, actualminute, statuscode)
VALUES ('Task 1', '2024-12-15', 120, 110, 1);
