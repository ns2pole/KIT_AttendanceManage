package com.example.AttandanceManage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttandanceManageApplication {

    public static void main(String[] args) {
        SpringApplication.run(AttandanceManageApplication.class, args);
    }
}
