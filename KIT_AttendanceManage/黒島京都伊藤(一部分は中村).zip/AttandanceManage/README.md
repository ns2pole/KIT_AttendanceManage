# KIT_AttendanceManage
田森くん css担当
田中くん ログイン
伊藤くん 連絡先登録
黒島くん 勤怠入力
櫻井さん 野間くん Css担当

user名passwordは
user - passwordか
admin - password